-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 22-08-2023 a las 10:25:12
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `medicamentos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `banners`
--

CREATE TABLE `banners` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `banners`
--

INSERT INTO `banners` (`id`, `image_path`, `created_at`, `updated_at`) VALUES
(3, '1692627816_1691358636_Screenshot_12.png', '2023-08-21 14:23:36', '2023-08-21 14:23:36'),
(4, '1692668377_1690855652_1690218397.png', '2023-08-22 01:39:37', '2023-08-22 01:39:37');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `summary` mediumtext DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `categories`
--

INSERT INTO `categories` (`id`, `title`, `summary`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Pastillas', '<p>Las mejores pastiilas<br></p>', 'active', '2023-08-22 11:58:40', '2023-08-22 11:58:40'),
(2, 'Antibioticos', 'Ad', 'active', '2023-08-22 08:02:15', '2023-08-22 08:02:15'),
(3, 'Suplementpos', NULL, 'active', '2023-08-22 08:22:04', '2023-08-22 08:22:04');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `medicamentos`
--

CREATE TABLE `medicamentos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `cat_id` bigint(20) UNSIGNED DEFAULT NULL,
  `detalles` mediumtext DEFAULT NULL,
  `fecha_vencimiento` date NOT NULL,
  `lote` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `registro_invima` varchar(255) DEFAULT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `cantidad` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `precio` decimal(10,2) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `medicamentos`
--

INSERT INTO `medicamentos` (`id`, `nombre`, `cat_id`, `detalles`, `fecha_vencimiento`, `lote`, `slug`, `registro_invima`, `imagen`, `cantidad`, `precio`, `status`, `created_at`, `updated_at`) VALUES
(1, 'acetaminofen', 2, 'BBNBNVHB', '2023-08-21', 'BHHJBH', 'acetaminofen', '67T76T67', '1692379680_1690218397.png', 20, 6000.00, 'inactive', '2023-08-18 17:28:00', '2023-08-22 02:12:17'),
(2, 'clururo de potasio', 2, 'sbfhsc', '2022-01-17', '2225', 'clururo-de-potasio', 'skdkskdskdks', '1692471865_1691745101_1690218372.png', 16, 5000.00, 'active', '2023-08-19 19:04:25', '2023-08-22 06:26:07'),
(3, 'dolex forte', 1, 'dfdfd', '2023-08-16', '2', 'dolex-forte', '455454', '1692583976_1691625232_descarga (1).jpg', 46, 4000.00, 'active', '2023-08-21 02:12:56', '2023-08-22 08:04:56');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2014_10_12_100000_create_password_resets_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2023_07_19_135437_create_medicamentos_table', 1),
(7, '2023_08_01_033905_create_ventas_table', 1),
(8, '2023_08_11_031652_create_banners_table', 1),
(9, '2023_08_12_212821_create_pedidos_table', 1),
(10, '2023_08_15_083449_create_categories_table', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `direccion` varchar(255) NOT NULL,
  `telefono` int(11) NOT NULL,
  `informacion` varchar(255) DEFAULT NULL,
  `status` enum('En Proceso','Finalizado','Cancelado') NOT NULL DEFAULT 'En Proceso',
  `productos` varchar(255) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `pedidos`
--

INSERT INTO `pedidos` (`id`, `nombre`, `email`, `direccion`, `telefono`, `informacion`, `status`, `productos`, `total`, `created_at`, `updated_at`) VALUES
(1, 'Administrador', 'admin@gmail.com', 'sdasd', 113213, NULL, 'En Proceso', 'clururo de potasio - Cantidad: 1, dolex forte - Cantidad: 1', 9000.00, '2023-08-22 06:26:07', '2023-08-22 06:26:07');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','vendor','customer') NOT NULL DEFAULT 'customer',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Administrador', 'admin@gmail.com', NULL, '$2y$10$zcUsThw8lX5xaA9W8/AaJe0XYTo9pZ2yvN3rtX9kU9JQlSdM7smLC', 'admin', 'active', NULL, NULL, NULL),
(2, 'Vendor', 'vendor@gmail.com', NULL, '$2y$10$d/l0coIN27B1tRh5IgxSReCkxkMxrXjhH9GskkOeaUp.cErxOumVG', 'vendor', 'active', NULL, NULL, NULL),
(3, 'Carlos customer', 'customer@gmail.com', NULL, '$2y$10$SKSr1ji9KmzQsmD.yM7xquB4owSVQ/mFk6iBDBmxONrFpxvqmHRAy', 'customer', 'active', NULL, NULL, NULL),
(4, 'Ludie Mann', 'sarai.hyatt@example.com', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer', 'inactive', 'TAhrKC8KC8', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(5, 'Dr. Beverly Daugherty III', 'bergstrom.mervin@example.net', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active', 'USM6evkVeK', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(6, 'Zena Pollich', 'chasity02@example.com', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'vendor', 'active', 'ACbuERKuxF', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(7, 'Lorna Muller DDS', 'reynolds.everette@example.net', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'vendor', 'inactive', 'q8d2h2aQTc', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(8, 'Garry Kassulke', 'sanford.marisa@example.net', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'vendor', 'active', 'oeFGMnc3Tg', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(9, 'Dr. Jarod Reinger IV', 'elijah26@example.com', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'vendor', 'inactive', 't6pG993ivj', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(10, 'Eloisa Lind', 'danielle.conroy@example.net', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer', 'inactive', 'VkKCZW5hWD', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(11, 'Mateo Parisian', 'xgreenholt@example.net', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'inactive', 'NIAwadR54p', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(12, 'Verna Fay', 'qmills@example.org', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'vendor', 'inactive', 'XyaOie4gNs', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(13, 'Miss Charity Bernhard', 'sgutkowski@example.org', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active', 'mv8WXA8HHk', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(14, 'Alfonzo Waelchi', 'skub@example.net', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer', 'inactive', 'pRVg8joPpc', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(15, 'Laney Schinner', 'ymorar@example.org', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer', 'inactive', 'IfoA69sPOi', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(16, 'Wilmer Kuhlman', 'anna.medhurst@example.org', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'vendor', 'inactive', '9p6ngMiFIb', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(17, 'Miss Alysa Heaney I', 'noemy.hansen@example.org', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer', 'inactive', '5E9FN8wEPn', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(18, 'Norberto Swaniawski', 'bbaumbach@example.net', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer', 'active', '3SzCvz7G8Y', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(19, 'Jacklyn Rohan', 'stanton.ludie@example.com', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer', 'inactive', 'Lxv0xUI5yN', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(20, 'Isobel Weissnat', 'bhintz@example.net', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active', 'cXpWhmE7y7', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(21, 'Sunny Kozey', 'aufderhar.sharon@example.org', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'inactive', 'DFDAYX7IoD', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(22, 'Dr. Mona Schumm III', 'oliver50@example.net', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer', 'inactive', 'hduwbXAeWR', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(23, 'Magnus Mann', 'cwisoky@example.com', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'vendor', 'inactive', 'A1Wa6CAjAF', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(24, 'Miss Laurie Zieme Sr.', 'batz.natalia@example.net', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer', 'inactive', 'ScissQPO9O', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(25, 'Prof. Zelma Klocko', 'alphonso65@example.org', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'vendor', 'active', 'xEMIEE6Ezv', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(26, 'Dwight Grant DDS', 'ferne.quitzon@example.org', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'vendor', 'inactive', 'Gpu3hUleXC', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(27, 'Dr. Doris Effertz', 'juana.hartmann@example.com', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active', 'NtN19SwiWN', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(28, 'Dr. Kacey Rolfson IV', 'kkub@example.org', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer', 'inactive', 'Tqy5yWv5R9', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(29, 'Larry Lueilwitz', 'june95@example.org', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer', 'active', 'OoYylr7Xh5', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(30, 'Ethan Emard', 'qhowe@example.org', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'inactive', 'N3lRs3ks4M', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(31, 'Kristopher Wunsch', 'yvette.thiel@example.com', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'inactive', 'AasmEXyQxb', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(32, 'Wilfredo Kunde', 'gregg.klein@example.org', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'inactive', 'QdVmY1pzar', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(33, 'Dr. Herman Doyle Sr.', 'waylon68@example.org', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'inactive', 'rch6HZ5wgd', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(34, 'Johanna Champlin', 'waelchi.buster@example.net', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'vendor', 'active', 'jE15OGCJXX', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(35, 'Adam Kris', 'willms.wilhelmine@example.com', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer', 'active', 'SpZJzaSLGF', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(36, 'Sydnee Becker', 'alphonso.okeefe@example.org', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'vendor', 'inactive', '4JvW9dr9xI', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(37, 'Josefa Kunde', 'veffertz@example.com', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'vendor', 'inactive', 'gzRdEChzNN', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(38, 'Norma Dibbert', 'maeve.kassulke@example.net', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active', 'Apk4ooodSe', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(39, 'Darrell Mitchell', 'kuphal.pinkie@example.org', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'inactive', 'zdYkgQsDRi', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(40, 'Dawn Lemke V', 'leilani14@example.org', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer', 'active', 'lud95wwjaj', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(41, 'Darrel Rohan IV', 'rluettgen@example.org', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active', 'QEjumz3Mg0', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(42, 'Berneice Flatley Sr.', 'schultz.hellen@example.net', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer', 'active', 'vz1W7n7PP1', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(43, 'Connor Kuhn', 'powlowski.maxine@example.net', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'vendor', 'active', 'U4YDI0qsz2', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(44, 'Mrs. Samanta Langworth', 'nstoltenberg@example.com', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active', 'c57XilKNk8', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(45, 'Abdullah Haag', 'gaylord.roselyn@example.net', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active', 'TVHcvMoLad', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(46, 'Jermey Wolff', 'abbott.morton@example.com', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'vendor', 'inactive', 'MSrwOGti8p', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(47, 'Eda Jones', 'lauretta30@example.org', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'vendor', 'inactive', 'tmg2RnELDp', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(48, 'Miss Michelle Kutch', 'laron.kuvalis@example.org', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'vendor', 'inactive', 'vUa7pnrNpL', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(49, 'Will Ledner', 'bryon.bartell@example.net', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer', 'inactive', '1an6I2GvC3', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(50, 'Keira Gleason IV', 'rconroy@example.org', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'inactive', 'GMVTmc87L7', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(51, 'Ashlynn DuBuque', 'harber.sister@example.org', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'vendor', 'active', 'koPSfSCWNP', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(52, 'Prof. Dock Ortiz DDS', 'dmclaughlin@example.com', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active', 'h9CfOuLc7C', '2023-08-18 02:33:30', '2023-08-18 02:33:30'),
(53, 'Skyla Dickens', 'gkuphal@example.org', '2023-08-18 02:33:30', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'inactive', 'cMOhYhZc0r', '2023-08-18 02:33:30', '2023-08-18 02:33:30');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `productos` varchar(255) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `fecha_venta` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`id`, `productos`, `total`, `fecha_venta`, `created_at`, `updated_at`) VALUES
(1, 'dolex forte - Cantidad: 2', 8000.00, '2023-08-22', '2023-08-22 05:41:11', '2023-08-22 05:41:11'),
(2, 'clururo de potasio - Cantidad: 2', 10000.00, '2023-08-22', '2023-08-22 05:41:16', '2023-08-22 05:41:16');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indices de la tabla `medicamentos`
--
ALTER TABLE `medicamentos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `medicamentos_slug_unique` (`slug`);

--
-- Indices de la tabla `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indices de la tabla `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `banners`
--
ALTER TABLE `banners`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `medicamentos`
--
ALTER TABLE `medicamentos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT de la tabla `ventas`
--
ALTER TABLE `ventas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
